#include "server.h"

#include <cstdio>
#include <cstring>
#include <string>

using namespace breeze;

int main(int argc, char ** argv) {
    if (argc < 2 || !strcmp(argv[1], "-h") || !strcmp(argv[1], "--help")) {
        printf("usage: breeze-server <model.gguf> [--host H] [--port P] [--webui] [--cpu] [--te-cpu]\n");
        printf("                     [--chunk-first N] [--chunk-max N] [--verbose]\n");
        printf("                     [--voices-dir PATH] [--ws-port P] [--split-chars N]\n");
        printf("                     [--cors [ORIGINS]] [--no-warmup] [--parallel N]\n");
        printf("                     [--talk] [--llm URL] [--tyger URL]\n");
        printf("\n");
        printf("  --chunk-first  fewest frames in the first streamed chunk, lower starts sooner (default 1).\n");
        printf("                 it goes up by itself when the gpu is too busy to stay ahead with that few\n");
        printf("  --chunk-max    frames the chunk ramps up to, higher is more efficient (default 25)\n");
        printf("                 set both the same to stream a fixed chunk size\n");
        printf("  --split-chars  default length long text is broken up at (default 600), 0 sends the\n");
        printf("                 whole thing through in one pass. a request can still override it\n");
        printf("  --verbose      add a per stage timing breakdown to each request\n");
        printf("  --voices-dir   folder of saved .breeze voices to load at startup (default voices)\n");
        printf("  --ws-port      websocket port for streaming sessions, default is the http port + 1,\n");
        printf("                 -1 turns it off\n");
        printf("  --cors         let browser pages on other origins call the api. on its own it allows\n");
        printf("                 any origin, or give a comma separated list like\n");
        printf("                 http://localhost:5173,https://app.example.com to allow only those\n");
        printf("  --te-cpu       run the text encoder on the cpu, saving about 1 gb of video memory for\n");
        printf("                 about 0.7 s more before each piece of text. dont use it with --parallel,\n");
        printf("                 it pauses the other streams\n");
        printf("  --parallel N   streams generating at once (default 1), more than that get told the\n");
        printf("                 server is busy. a stream using cfg counts as two\n");
        printf("  --talk         serve the voice call demo at /talk, needs tyger-server and an llm\n");
        printf("  --llm URL      openai compatible server the demo gets its replies from, passed\n");
        printf("                 through under /llm/ (default http://127.0.0.1:1234/v1 with --talk)\n");
        printf("  --tyger URL    tyger-server websocket for the demo (default ws://127.0.0.1:8765/ws)\n");
        printf("  --no-warmup    skip the short throwaway generation at startup, the first request\n");
        printf("                 then pays for setting up the gpu pipelines instead\n");
        return argc < 2 ? 1 : 0;
    }
    ServerOptions opts;
    opts.model = argv[1];
    for (int i = 2; i < argc; i++) {
        std::string a = argv[i];
        if (a == "--host" && i + 1 < argc) opts.host = argv[++i];
        else if (a == "--port" && i + 1 < argc) opts.port = atoi(argv[++i]);
        else if (a == "--webui") opts.webui = true;
        else if (a == "--verbose" || a == "-v") opts.verbose = true;
        else if (a == "--voices-dir" && i + 1 < argc) opts.voices_dir = argv[++i];
        else if (a == "--ws-port" && i + 1 < argc) opts.ws_port = atoi(argv[++i]);
        else if (a == "--cpu") opts.use_gpu = false;
        else if (a == "--te-cpu") opts.te_cpu = true;
        else if (a == "--chunk-first" && i + 1 < argc) opts.chunk_first = atoi(argv[++i]);
        else if (a == "--chunk-max" && i + 1 < argc) opts.chunk_max = atoi(argv[++i]);
        else if (a == "--split-chars" && i + 1 < argc) opts.split_chars = atoi(argv[++i]);
        else if (a == "--no-warmup") opts.warmup = false;
        else if (a == "--parallel" && i + 1 < argc) opts.parallel = atoi(argv[++i]);
        else if (a == "--talk") opts.talk = true;
        else if (a == "--llm" && i + 1 < argc) opts.llm = argv[++i];
        else if (a == "--tyger" && i + 1 < argc) opts.tyger = argv[++i];
        else if (a == "--cors") {
            // origins start with a scheme, so a dash here is the next flag not an origin list
            opts.cors = "*";
            if (i + 1 < argc && argv[i + 1][0] != '-') opts.cors = argv[++i];
        }
        else { fprintf(stderr, "unknown arg: %s\n", a.c_str()); return 1; }
    }
    if (opts.split_chars < 0) opts.split_chars = 0;
    if (opts.talk && opts.llm.empty()) opts.llm = "http://127.0.0.1:1234/v1";
    if (opts.parallel < 1) {
        fprintf(stderr, "--parallel must be at least 1\n");
        return 1;
    }
    if (opts.chunk_first < 1 || opts.chunk_max < 1) {
        fprintf(stderr, "chunk sizes must be at least 1\n");
        return 1;
    }
    return run_server(opts);
}
