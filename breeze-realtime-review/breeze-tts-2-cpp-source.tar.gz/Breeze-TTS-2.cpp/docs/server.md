# Server API

`breeze-server` is a single binary HTTP server built on cpp-httplib. It loads
one model, serves it over HTTP, and streams raw PCM as the audio is generated
rather than waiting for the whole clip.

| Endpoint | Purpose |
| --- | --- |
| `GET /health` | Liveness, sample rate, websocket port |
| `POST /v1/audio/speech` | Generate speech, streamed. Also takes OpenAI style JSON, see [OpenAI compatible requests](#openai-compatible-requests) |
| `POST /v1/audio/convert` | Respeak a recording in another voice, see [voice-conversion.md](voice-conversion.md) |
| `POST /v1/voices` | Register or save a reference voice, see [voices.md](voices.md) |
| `GET /v1/voices` | List cached and saved voices |
| `GET /v1/voices/<id>` | One voice, with its description and metadata |
| `PATCH /v1/voices/<id>` | Change a voice's description and metadata, see [voices.md](voices.md#descriptions-and-metadata) |
| `DELETE /v1/voices/<id>` | Drop a voice from memory |

A separate WebSocket listener handles incremental text, mid stream direction
changes and interruption. It is documented in [websocket.md](websocket.md).

## Starting the server

```
breeze-server <model.gguf> [--host H] [--port P] [--webui] [--cpu]
                           [--chunk-first N] [--chunk-max N] [--verbose]
                           [--voices-dir PATH] [--ws-port P] [--split-chars N]
                           [--cors [ORIGINS]] [--no-warmup] [--parallel N]
                           [--talk] [--llm URL] [--tyger URL]
```

| Flag | Default | Meaning |
| --- | --- | --- |
| `--host` | `127.0.0.1` | Interface to bind. Use `0.0.0.0` to accept remote connections. |
| `--port` | `8080` | TCP port. |
| `--webui` | off | Also serve the browser UI at `/`. |
| `--cpu` | off | Force the CPU backend instead of Vulkan. |
| `--te-cpu` | off | Run the text encoder on the CPU and keep its weights in system memory, saving about 1 GB of video memory. Adds about 0.7 s before each piece of text, about 1.3 s with guidance. Do not combine it with `--parallel`, it pauses the other streams. See [performance.md](performance.md#short-on-video-memory). |
| `--chunk-first` | `1` | Fewest frames in the first streamed chunk. It goes up on its own when the GPU is too busy to stay ahead with that few. |
| `--chunk-max` | `25` | Frames the chunk ramps up to. |
| `--verbose` | off | Add a per stage timing breakdown after each request. |
| `--voices-dir` | `voices` | Folder of saved `.breeze` voices to load at startup. See [voices.md](voices.md). |
| `--ws-port` | HTTP port + 1 | Port for streaming sessions. `-1` disables it. See [websocket.md](websocket.md). |
| `--split-chars` | `600` | Default length long text is broken up at. `0` sends the whole thing through in one pass. A request can still override it. |
| `--cors` | off | Let browser pages on other origins call the API. On its own it allows any origin; give a comma separated list to allow only those. See [Cross origin requests](#cross-origin-requests). |
| `--no-warmup` | off | Skip the warm up at startup. See below. |
| `--parallel` | `1` | Streams generating at once. A stream using guidance counts as two. See [performance.md](performance.md#running-several-streams). |
| `--talk` | off | Serve the voice call demo at `/talk`. See [Voice call demo](#voice-call-demo). |
| `--llm` | `http://127.0.0.1:1234/v1` with `--talk` | OpenAI compatible server the demo gets its replies from, passed through under `/llm/`. |
| `--tyger` | `ws://127.0.0.1:8765/ws` | tyger-server websocket the demo uses for turn taking. |

```
breeze-server breeze-tts-2-q4_k.gguf --port 8137 --webui
```

Before it starts listening the server runs a short throwaway generation for every
mix of streams its `--parallel` setting allows, with and without guidance, and
decodes a few sizes of audio chunk. That sets up the GPU pipelines the first real
request would otherwise have to build. The first request after startup then reaches
first audio in about 200 to 350 ms on an RTX 3060, and later ones in about 80 ms. It
adds about 3 s to startup at `--parallel 1` and about 8 s at `--parallel 4`.
`--no-warmup` skips it.

## Console output

Each request prints a progress bar that fills as audio is streamed, then a
summary.

```
gen  design, 291 chars, cfg 1.0, seed 7
 87%|████████████████████▉   | 15.1/17.4s [00:11<00:01, 16.2 fps, 1.30x]
100%|████████████████████████| 19.4/19.4s [00:15, 16.1 fps, 1.29x]
     242 frames in 11 flushes, first audio 588 ms
```

The total is estimated from the text, since the model decides for itself when to
stop, so the bar can reach 100% early or run past its estimate. The last line
rewrites it with the real figure. `fps` is frames generated per second against
12.5 frames of audio per second, so the trailing number is the real time factor
and anything above `1.00x` is faster than playback.

With `--parallel` above 1 the moving bar is left out, because several streams would
write over each other. The final bar and the summary still print for each request.

There is no authentication and no rate limiting, on either the HTTP port or the
WebSocket one. Do not expose them directly to the internet; put them behind a
reverse proxy that handles both.

## Cross origin requests

The bundled web UI is served from the same origin as the API, so it needs
nothing. A page served from anywhere else, a Vite dev server or a separate front
end for instance, is blocked by the browser unless the server sends CORS
headers. It does not by default. Turn them on with `--cors`:

```
breeze-server model.gguf --cors
breeze-server model.gguf --cors http://localhost:5173,https://app.example.com
```

On its own the flag answers every origin with `Access-Control-Allow-Origin: *`.
With a list it reflects the request's `Origin` only when it matches an entry
exactly, scheme and port included, and adds `Vary: Origin` so caches keep the
answers apart. An origin that is not on the list gets no CORS headers and the
browser refuses the response.

`X-Sample-Rate` and `X-Sample-Format` are listed in
`Access-Control-Expose-Headers`, so a cross origin page can read the sample
rate the same way the bundled UI does. Preflight `OPTIONS` requests, which the
browser sends before `DELETE` and `PATCH` on `/v1/voices/<id>`, are answered
with `204` and cached for a day.

The WebSocket port is not affected. Browsers do not apply CORS to WebSockets,
and the socket accepts a connection from any page regardless of this flag, as
[websocket.md](websocket.md) notes.

## Streaming without stutter

Two numbers decide whether a stream plays cleanly, and they fail in different
ways. Getting one right does not save you from the other.

### Real time factor

The real time factor is seconds of audio produced per second of wall clock. Above
1.0 the model outruns playback, below it no amount of buffering will help because
the client drains faster than the server fills.

Measure it against your own hardware rather than assuming:

```
curl -s -o out.pcm -w "%{time_total}\n" \
  --form-string "text=<a sentence long enough to take several seconds>" \
  http://127.0.0.1:8137/v1/audio/speech
```

Audio seconds are `bytes / 2 / 24000`, so the factor is that divided by
`time_total`. On an RTX 3060 a long clip measures about 2.4x at Q4_K and 2x at
Q8_0 with the defaults. A busy GPU still eats into that, and so do other streams,
see [performance.md](performance.md#running-several-streams).

Guidance costs less than it looks like it should. `cfg_scale` above 1 adds a
second forward pass, but the depth decoder batches both branches into one graph,
so a 16 second passage at `cfg_scale` 3 measures 1.74x at Q4_K and 1.59x at
Q8_0, still comfortably above realtime. Cloning also adds a one off
reference encode of roughly 650 ms, which shows up in time to first audio rather
than in the rate.

If you land near or below 1.0, no client setting will fix it. Drop to a smaller
quantisation, lower `--parallel`, or use a faster device. Raising `--chunk-max` no
longer helps here. Quantising the depth
decoder with `--depth` also helps, but it damages the high end and the damage
grows over a long passage, so weigh it against the numbers in
[models.md](models.md).

### Queue depth

This is the one that actually causes stutter on a machine whose real time factor
looks fine.

The client's queue drains continuously but refills in one lump per chunk, so the
queue has to be deeper than the time it takes to produce a whole chunk. At
`--chunk-max 40` a chunk is 3.2 s of audio that takes roughly 2 s to generate,
so a client holding only 0.5 s of audio runs dry waiting for it, even though the
average rate is comfortably ahead.

The server now handles most of this itself. It assumes playback starts the
moment each chunk lands and keeps track of when that audio will run out. If
waiting to fill the current chunk would leave the client with nothing to play,
it sends the frames it already has early instead, and holds the chunk size until
the cushion builds back up. It only does this when the short chunk plays for
longer than it takes to generate and decode, because otherwise a run of tiny
chunks would fall further behind rather than catch up. The time it goes by includes
any other streams sharing the GPU.

Measured on an RTX 3060 at Q8_0, when early flushing went in, with a client that
starts playing on the very first packet and buffers nothing, reading a 21 second
passage at `cfg_scale` 3, the slowest common case:

| `--chunk-max` | Before | Early flushing | Plus the one graph depth decoder |
| --- | --- | --- | --- |
| 25 | 5 gaps, 222 ms of silence | none | none |
| 40 | 6 gaps, 308 ms | 1 gap, 73 ms | none |
| 60 | 7 gaps, 442 ms | 1 gap, 18 ms | none |

Without guidance there were no gaps in any of them. The early flushes cost a few
percent of throughput under guidance, 1.17x against 1.22x at the default, and the
faster depth decoder more than wins it back at 1.33x. The current build reads a 16
second passage this way at 1.59x with no gaps.

The old rule still gives the most margin: **buffer more audio than the slowest
chunk takes to produce.** The bundled UI prebuffers 1.25 s. It just matters much
less now, and a client that cannot buffer at all will mostly get away with it.

Note the difference between prebuffering and delaying. Starting the first chunk
half a second late does not create a cushion, it only shifts the start; the queue
still holds one chunk. Accumulate chunks until you are actually holding N seconds
of audio, then play them back to back. The bundled UI does this and exposes N as
the buffer slider.

### Tuning the chunk ramp

Audio is vocoded in chunks of whole frames at 12.5 frames per second. The first
chunk sets how long the client waits for sound, so the chunk starts small and
grows by a third each flush until it reaches `--chunk-max`.

The vocoder keeps its state between flushes and only decodes the new frames, so
small chunks are cheap now and raising the ceiling no longer buys anything. Measured
on an RTX 3060 at Q8_0 over an 18 second clip:

| `--chunk-max` | Flushes | Vocoder per frame |
| --- | --- | --- |
| 8 | 31 | 2.90 ms |
| 25 | 15 | 2.17 ms |
| 50 | 13 | 2.16 ms |

Lowering it is the useful direction if a client wants a smaller buffer. Going to 8
costs about 2% of total speed.

`--chunk-first` is a minimum, and the default of 1 frame is the fastest start. The
server raises the first chunk by itself when the GPU is too busy for that. Setting 4
took first audio from 278 ms to 394 ms in `breeze-cli` at Q8_0, and saved only 0.14 ms
per frame.

Setting both flags to the same value disables the ramp and streams a fixed size.
[performance.md](performance.md#tuning-settings) has the rest.

### Summary

- Leave `--chunk-max` at the default, or lower it if you want a smaller client buffer.
- The server sends early when a client is about to run dry, so a small buffer is
  enough. Around 1 s still gives the most margin under guidance.
- Prebuffer by fill level, not by delay.
- Check the real time factor first if it stutters no matter what you buffer.

## `GET /health`

Liveness probe. Returns once the model is loaded and ready.

```
curl http://127.0.0.1:8137/health
```

```json
{"status":"ok","sample_rate":24000,"ws_port":8081}
```

The server does not accept connections until loading finishes, so a successful
response also means the model is warm. Poll this after startup instead of
guessing at a delay.

`ws_port` is where the streaming socket ended up, or `0` when it is disabled, so
clients can discover it rather than being configured with it.

## `POST /v1/audio/speech`

Generates speech and streams it back.

Accepts `multipart/form-data` (needed for the reference audio upload) or
`application/x-www-form-urlencoded`.

### Fields

| Field | Type | Default | Meaning |
| --- | --- | --- | --- |
| `text` | string | required | Text to speak, UTF-8. |
| `instruction` | string | `Speak clearly and naturally.` | Voice description or delivery direction. |
| `ref_audio` | file | none | Reference WAV for cloning. Any sample rate or channel count; resampled to mono at the model rate. Identical repeated uploads (same bytes and transcript) reuse the reference encode from the in-memory hash cache instead of re-encoding; see [voices.md](voices.md). |
| `ref_text` | string | empty | Exact transcript of `ref_audio`. Required whenever `ref_audio` is present. |
| `voice_id` | string | none | A saved or cached voice to clone instead of uploading a clip. Skips the reference encode. See [voices.md](voices.md). |
| `cfg_scale` | float | `1.0` | Classifier free guidance. `1.0` disables it. |
| `seed` | int | `42` | RNG seed. |
| `temperature` | float | model default | Sampling temperature. `0` keeps whatever the GGUF was built with. |
| `top_k` | int | model default | Sampling top-k. `0` keeps the model default. |
| `top_p` | float | model default | Sampling top-p. `0` keeps the model default. |
| `repetition_penalty` | float | model default | Repetition penalty. `0` keeps the model default. |
| `split_chars` | int | `--split-chars` | Long text is split on sentence boundaries into pieces of about this size and generated one at a time. `0` generates in one pass. |
| `max_new_tokens` | int | model default | Frame cap per piece, 12.5 frames per second. `0` uses the model default of 750. |

Every sampling field treats `0` as "use the model default", so leaving them out
behaves exactly as before rather than forcing a zero.

There is no length limit on `text`. Anything past the budget is split and
generated piece by piece, each conditioned on the first so the voice does not
change partway. Generating minutes in a single pass is what `split_chars 0`
does, and the model loses track of the text well before it runs out of frames,
so leave splitting on unless you have a reason not to. Starting the server with
`--split-chars 0` turns it off for every request that does not set its own.

### Response

`200 OK` with a chunked body.

| Header | Value |
| --- | --- |
| `Content-Type` | `audio/pcm` |
| `Transfer-Encoding` | `chunked` |
| `X-Sample-Rate` | `24000` |
| `X-Sample-Format` | `s16le` |
| `Cache-Control` | `no-store` |

The body is **headerless** signed 16 bit little endian mono PCM. It is not a
WAV file. Wrap it yourself if you need one, or use the CLI which writes WAV
directly.

Chunks arrive roughly every 2 seconds of generated audio, so playback can start
long before generation finishes.

### Errors

| Status | Body | Cause |
| --- | --- | --- |
| `400` | `{"error":"text is required"}` | `text` missing or empty. |
| `404` | `{"error":"unknown voice_id"}` | No cached or saved voice by that name. |
| `409` | `{"error":"busy"}` | Every generation slot is taken. |

The server holds one model and by default serves one request at a time. `--parallel`
raises that, and a request using guidance takes two slots, see
[performance.md](performance.md#running-several-streams). A request that does not
fit is rejected immediately with `409` rather than queued, so clients should retry
with backoff. The WebSocket endpoint queues instead of refusing, which is one reason
to prefer it for anything conversational.

Because the response is streamed, a failure that happens **after** the first
chunk cannot change the status code. The connection is closed early instead, so
treat a truncated body as an error.

### Examples

Send text fields with `--form-string`, not `-F`. `curl` reads a value that starts
with `(` as the opening of a multipart group, so `-F "text=(sigh) ..."` posts an
empty field and the model ends up reading the multipart boundary out loud.

Voice design:

```
curl -X POST http://127.0.0.1:8137/v1/audio/speech \
  --form-string "text=Welcome aboard. Your journey begins now." \
  --form-string "instruction=A warm, thoughtful young woman with a clear, calm delivery." \
  --form-string "cfg_scale=1" \
  --form-string "seed=42" \
  -o speech.pcm
```

Voice clone:

```
curl -X POST http://127.0.0.1:8137/v1/audio/speech \
  --form-string "text=It is good to hear your voice again." \
  -F "ref_audio=@reference.wav" \
  --form-string "ref_text=This is the exact transcript of the reference audio." \
  -o clone.pcm
```

Voice direction, which is a clone plus an instruction:

```
curl -X POST http://127.0.0.1:8137/v1/audio/speech \
  --form-string "text=We need to discuss what happened last night." \
  --form-string "instruction=Speak slowly with a restrained, serious tone." \
  -F "ref_audio=@reference.wav" \
  --form-string "ref_text=This is the exact transcript of the reference audio." \
  --form-string "cfg_scale=1" \
  -o direction.pcm
```

Play the raw stream straight out of `curl`:

```
curl -sN -X POST http://127.0.0.1:8137/v1/audio/speech --form-string "text=Hello there." \
  | ffplay -f s16le -ar 24000 -ac 1 -nodisp -autoexit -
```

Convert to WAV:

```
ffmpeg -f s16le -ar 24000 -ac 1 -i speech.pcm speech.wav
```

## OpenAI compatible requests

`POST /v1/audio/speech` also takes the JSON body of OpenAI's speech API, so
apps built for it, like SillyTavern or the official OpenAI SDKs, can point at
the server as they are. The `Content-Type` header decides which one you get:
`application/json` gets the behaviour described here, a form post gets the
native behaviour above.

```
curl http://127.0.0.1:8137/v1/audio/speech \
  -H "Content-Type: application/json" \
  -d '{"model":"tts-1","input":"Hello from Breeze.","voice":"narrator","response_format":"mp3"}' \
  -o speech.mp3
```

With the Python SDK:

```python
from openai import OpenAI

client = OpenAI(base_url="http://127.0.0.1:8137/v1", api_key="unused")
with client.audio.speech.with_streaming_response.create(
    model="tts-1", voice="narrator", input="Streaming from the OpenAI SDK.",
) as r:
    r.stream_to_file("speech.mp3")
```

### Fields

| Field | Type | Default | Meaning |
| --- | --- | --- | --- |
| `input` | string | required | Text to speak, UTF-8. |
| `voice` | string or `{"id": ...}` | none | A saved or cached voice, the same ids `voice_id` takes. Leave it out to design a voice from `instructions` instead. |
| `instructions` | string | `Speak clearly and naturally.` | Voice description when designing, delivery direction when cloning. |
| `response_format` | string | `mp3` | `mp3`, `wav` or `pcm`. `opus`, `aac` and `flac` are accepted but sent as WAV. |
| `stream_format` | string | `audio` | `audio` streams the file itself, `sse` wraps it in server sent events. |
| `model` | string | ignored | Accepted so clients that always send one keep working. |
| `speed` | number | ignored | The model has no speed control. |

The native fields `cfg_scale`, `seed`, `temperature`, `top_k`, `top_p`,
`repetition_penalty`, `max_new_tokens` and `split_chars` are accepted as extra
JSON fields, with the same meaning and defaults as above.

OpenAI's own voice names such as `alloy` or `nova` are not built in, and a name
the server does not know is a `404`. If a client insists on those names, save
voices under them with `POST /v1/voices` (see [voices.md](voices.md)) and they
work like any other.

### Formats

| `response_format` | Sent as | `Content-Type` |
| --- | --- | --- |
| `mp3` | MP3, 80 kbps mono at 48 kHz | `audio/mpeg` |
| `wav` | 16 bit mono WAV at 24 kHz | `audio/wav` |
| `pcm` | Headerless s16le mono at 24 kHz, the same as the native endpoint and OpenAI's own `pcm` | `audio/pcm` |
| `opus`, `aac`, `flac` | WAV | `audio/wav` |

Every format streams as it is generated, so playback can start on the first
chunk. The WAV header goes out first with its length fields set to the maximum,
because the length is not known yet. Browsers and ffmpeg read that to the end
of the stream.

MP3 is encoded with [shine](https://github.com/toots/shine), which builds from
the `third_party/shine` submodule. It is upsampled to 48 kHz first, because Chrome
and Edge reject the frames shine writes at 24 kHz, so `X-Sample-Rate` says 48000
on an MP3 response. A build without it, or one configured with
`-DBREEZE_MP3=OFF`, sends WAV when asked for `mp3` as well. The console line for
each request says what actually went out, for example `openai wav for opus`.

### Server sent events

With `"stream_format": "sse"` the response is `text/event-stream`. Each chunk
arrives as a `speech.audio.delta` event carrying the next bytes of the file in
`response_format`, base64 encoded, and a `speech.audio.done` event ends it.

```
data: {"type":"speech.audio.delta","audio":"//NIxAAAAAAAAAAAAFhpbmcAAAAPAAAA..."}

data: {"type":"speech.audio.done","usage":{"input_tokens":0,"output_tokens":0,"total_tokens":0}}
```

Decoding the deltas and joining them gives the same file a plain request
returns. The token counts are always zero.

### Errors

Errors on this path use OpenAI's error shape, so clients show the message
instead of a bare status code.

```json
{"error":{"message":"input is required","type":"invalid_request_error","param":null,"code":null}}
```

| Status | Cause |
| --- | --- |
| `400` | The body is not a JSON object, `input` is missing, or a field has the wrong type or an unknown value. |
| `404` | `voice` is not a saved or cached voice. |
| `409` | Every generation slot is taken. The OpenAI SDKs retry this on their own. |

The `Authorization` header is ignored, so any API key works. That also means
there is still no authentication, see the warning above.

### SillyTavern

Open the TTS extension, pick **OpenAI Compatible** as the provider and fill in:

| Setting | Value |
| --- | --- |
| Provider Endpoint | `http://127.0.0.1:8137/v1/audio/speech` |
| API Key | Anything, it is ignored. |
| Model | Anything, it is ignored. |
| Available Voices | The voice ids you want, comma separated, e.g. `narrator,harbour`. The list from `GET /v1/voices` has them all. |

The default voice list is OpenAI's names, which will all come back `404` until
you replace it. Speed does nothing. SillyTavern asks for MP3, which is what it
gets.

## Streaming client sketch

```python
import struct
import urllib.request

body, boundary = build_multipart({"text": "Streaming from python."})
req = urllib.request.Request(
    "http://127.0.0.1:8137/v1/audio/speech",
    data=body,
    headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
)

with urllib.request.urlopen(req) as r:
    rate = int(r.headers["X-Sample-Rate"])
    tail = b""
    while chunk := r.read(8192):
        chunk = tail + chunk
        n = len(chunk) // 2
        tail = chunk[n * 2:]
        samples = struct.unpack(f"<{n}h", chunk[:n * 2])
        play(samples, rate)
```

Buffer any odd trailing byte between reads, since a chunk boundary can land in
the middle of a sample.

## Web UI

`--webui` mounts a dark brutalist single page UI that mirrors the reference
Gradio demo.

| Route | Serves |
| --- | --- |
| `GET /` | `index.html` |
| `GET /style.css` | stylesheet |
| `GET /app.js` | client script |

It has three tabs matching the three generation modes, and it posts to the same
`/v1/audio/speech` endpoint.

**Stream while generating** is on by default. The UI reads the response body
incrementally and schedules each PCM chunk through the Web Audio API as it
arrives, so playback starts about a second in rather than after the whole clip is
rendered. A running counter shows how much audio has been produced, and appends a
rebuffer count if the queue ever ran dry. When generation finishes the same PCM
is wrapped into a WAV blob for the player and the download link.

**Buffer** is how much audio the UI holds before it starts playing, not how long
it waits. Chunks accumulate until that much is queued, then play back to back.
The default of 1.25 s covers the defaults here; raise it if you raised
`--chunk-max` or see rebuffers, lower it if you want a faster start and your real
time factor has room. If the queue does run dry the UI widens its own buffer for
the rest of that clip rather than stuttering repeatedly.

Turn the toggle off to buffer the whole response first and play it back from the
`<audio>` element, which is the better choice if you want to scrub the result
rather than hear it as early as possible.

The assets are compiled into the binary at build time from the
[webui](../webui) folder by `cmake/embed_webui.cmake`, so there is no static
directory to deploy. Editing a file there and rebuilding is enough to pick up
changes.

## Voice call demo

`--talk` serves a voice call page at `/talk`. You pick a character, it picks up,
and you talk to it out loud. It needs two other things running:

- [tyger-server](https://github.com/HoppouAI/tyger.cpp) for speech recognition and
  turn taking. It decides when you finished talking, when you are interrupting, and
  when a short "mm-hmm" fits.
- Any OpenAI compatible chat server, such as LM Studio, Ollama or llama.cpp's
  server, for the replies. The page calls it through `/llm/` on this server, so
  the chat server does not need CORS.

```
tyger-server -m models/tyger-q8_0.gguf --port 8765
breeze-server breeze-tts-2-q4_k.gguf --talk --llm http://127.0.0.1:1234/v1
```

Then open http://127.0.0.1:8080/talk. Headphones work best, since the page has
no echo cancellation of its own beyond what the browser does.

The page reaches everything through the address you opened it on. The speech
socket goes to that host, the chat server goes through `/llm/` on this server,
and a loopback `--tyger` address like the default is swapped for that host
too. To use it from another device, start both servers with `--host 0.0.0.0`.
Browsers only allow the microphone on https or on localhost, so from another
device the page has to be served over https, for example behind a reverse
proxy. Behind https the sockets switch to `wss://` on their own.

| Route | Serves |
| --- | --- |
| `GET /talk` | the page |
| `GET /talk/config` | websocket port, tyger address and sample rate for the page |
| `GET, POST /llm/...` | passed through to the `--llm` server, streaming |

Replies stream from the chat server straight into a [WebSocket](websocket.md)
session. The first clause goes out with `flush` so speech starts before the
sentence is finished, and the rest follows as `text`. When you talk over the
character the session is cancelled, and only the part you actually heard goes
into the chat history, ending in "..." so the model knows it was cut off.

Everything is set in the page under Settings and kept in the browser:

- **Characters.** Name, color, personality and an optional opening line. The
  voice is either a saved voice or a description for voice design. A saved voice
  sounds the same every call; a designed one changes a little each time. The
  page can also clone a new voice from a file or a recording, transcribing it
  with tyger.
- **Speaking rules.** Added after every character's personality. The defaults
  keep replies short and casual, use "..." for pauses, and allow vocal event tags
  like `(laugh)` or `(sigh)` so the voice can actually laugh.
- **Turn taking.** How long to wait before replying, whether you can interrupt
  and how easily, and backchannels. tyger's own interrupt score misses short
  ones like "wait, hold on", so talking over the character for about a second
  stops it too. When an interruption turns out to be just "mm-hmm" or nothing
  at all, the character picks up where it stopped. Backchannels are short
  phrases made once per call in the character's voice; with no saved voice
  they start after the first reply, cloned from it. They can also be written
  by the chat model from what you are saying, which fits better but takes
  about a second each.
- **Voice.** Guidance and temperature for the speech model.
- **Screen sharing.** The Share screen button in a call lets the character see
  your screen, like a video call. While you share, a fresh picture of the
  screen goes with everything you say, and only the newest one is sent, so the
  chat history stays text. It needs a chat model that takes images. If yours
  does not, the page says so and the character answers without the picture.
  The picture size setting trades readable small text against time before
  each reply.
- **Conversation.** Which chat model, temperature, reply length, an API key for
  hosted servers, and whether to skip the thinking step on reasoning models.
