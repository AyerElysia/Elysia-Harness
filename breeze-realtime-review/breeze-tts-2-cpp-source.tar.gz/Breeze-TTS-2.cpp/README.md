<div align="center">

# Breeze-TTS-2.cpp

**Bilingual instruction following text to speech in C++ and GGUF.**
Voice design, voice cloning, voice direction and experimental voice conversion,
streaming at better than realtime on a mid range GPU.

<a href="LICENSE"><img src="https://img.shields.io/badge/license-Apache_2.0-1f6feb?style=for-the-badge" alt="License"></a>
<img src="https://img.shields.io/badge/C%2B%2B-17-00599C?style=for-the-badge&logo=cplusplus&logoColor=white" alt="C++17">
<img src="https://img.shields.io/badge/Vulkan-AC162C?style=for-the-badge&logo=vulkan&logoColor=white" alt="Vulkan">
<a href="https://huggingface.co/HoppouAI/Breeze-TTS-2.cpp"><img src="https://img.shields.io/badge/GGUF_weights-FFD21E?style=for-the-badge&logo=huggingface&logoColor=black" alt="GGUF weights"></a>

</div>

A C++ / GGUF reimplementation of [BreezeBlue/Breeze-TTS-2](https://huggingface.co/BreezeBlue/Breeze-TTS-2),
running on [ggml](https://github.com/ggml-org/ggml). The Vulkan backend means it works across NVIDIA,
AMD and Intel GPUs, and it falls back to CPU. Ships a CLI, a streaming HTTP and WebSocket server with
a web UI, and a plain C shared library for bindings.

English and Mandarin, 24 kHz, roughly 2x realtime at Q8_0 on an RTX 3060, 1.6x with guidance, and the
server can run a few streams at once.

## Demo

Voice design, cloning, direction, vocal event tags, and voice conversion on a sung recording. Every
clip was generated on one RTX 3060, faster than realtime, and nothing was cherry picked.

https://github.com/user-attachments/assets/b63e4664-497f-4bac-b9e2-50bf571df30a

## Performance

Recent versions borrow from [BreezeRT](https://breezeblue.ai/blog/breezert-ultra-low-latency-tts),
the low latency runtime from the Breeze TTS 2 team: chunks that start small and grow, the depth
decoder compiled into one graph per frame, CUDA graph replay, a vocoder that keeps its state and only
decodes new frames, and several streams sharing one GPU batch. On top of that, the vocoder upsamples
with a matmul, which is not from that post and was the biggest single win on CUDA.

Real time factor for one stream on one RTX 3060 12 GB, with its tensor core limit unlocked, v0.1.5 and
v0.1.6 run back to back on the same seeds:

| Model | `cfg_scale` | v0.1.5 | v0.1.6 |
| --- | --- | --- | --- |
| Q4_K | 1 | 2.15x | 2.41x |
| Q4_K | 3 | 1.53x | 1.74x |
| Q8_0 | 1 | 1.78x | 1.99x |
| Q8_0 | 3 | 1.46x | 1.58x |

That is on Vulkan. CUDA at Q4_K measures 2.12x, and 1.70x at `cfg_scale` 3.

Time to first audio on a warmed up server is about 80 ms, down from about 180 ms on v0.1.5.

On a stock RTX 3080 12 GB, no unlock, same version and Vulkan, median of 4 seeds:

| Model | `cfg_scale` 1 | `cfg_scale` 3 |
| --- | --- | --- |
| Q4_K | 3.50x | 2.81x |
| Q6_K | 3.67x | 2.87x |
| Q8_0 with a Q4_K depth decoder | 3.72x | 2.83x |
| Q8_0 | 3.16x | 2.71x |
| F16 | 2.71x | 2.32x |

It has far more memory bandwidth than the 3060, so the weight type matters much less there: Q8_0 is
only about 10% behind Q4_K, and even F16 runs well ahead of realtime.

### Several streams at once

Start the server with `--parallel 3` and it generates up to three streams together, sharing one GPU
batch per frame. On the same card, with nothing buffered on the client and streams starting a second
apart:

| Streams | Model | Speed of each stream | Gaps |
| --- | --- | --- | --- |
| 3 | Q8_0 | 1.24x to 1.32x | none |
| 3 | Q8_0 with a Q4_K depth decoder | 1.42x to 1.51x | none |
| 3 | Q4_K on CUDA | 1.38x to 1.52x | none |
| 1 with guidance, 2 without | Q8_0 | 1.15x to 1.28x | none |
| 2 with guidance | Q8_0 | 1.16x to 1.19x | none |
| 3 with guidance | Q8_0 | 0.87x to 0.95x | about 3 s, does not keep up |

On the RTX 3080 every one of these keeps up, the last one included, at about 1.5x for three
streams with guidance. Five streams at Q8_0 run at 1.46x to 1.68x each with no gaps, and
`--parallel 6` is safe with any model, see
[docs/performance.md](docs/performance.md#several-streams-on-an-rtx-3080).

A stream using guidance counts as two, so `--parallel 4` fits any of these except the last one. When
every slot is taken, the HTTP routes answer `409` and a WebSocket session waits its turn.

### Tuning

The defaults are the fastest settings measured, so most setups need nothing except `--parallel`.
Which model to pick, how many streams a card can hold, what each setting does now and how to measure
your own card are all in [docs/performance.md](docs/performance.md). One change to know about: if you
raised `--chunk-max` on an older version, take it off, it no longer gains anything.

Vulkan stays the default, the reasons and the per stage numbers are in [docs/build.md](docs/build.md).

## Documentation

<div align="center">

<a href="docs/build.md"><img src="https://img.shields.io/badge/Build-2b3137?style=for-the-badge" alt="Build"></a>
<a href="docs/models.md"><img src="https://img.shields.io/badge/Models-2b3137?style=for-the-badge" alt="Models"></a>
<a href="docs/cli.md"><img src="https://img.shields.io/badge/CLI-2b3137?style=for-the-badge" alt="CLI"></a>
<a href="docs/server.md"><img src="https://img.shields.io/badge/HTTP_Server-2b3137?style=for-the-badge" alt="Server"></a>
<a href="docs/websocket.md"><img src="https://img.shields.io/badge/WebSocket-2b3137?style=for-the-badge" alt="WebSocket"></a>
<br>
<a href="docs/voices.md"><img src="https://img.shields.io/badge/Saved_Voices-2b3137?style=for-the-badge" alt="Voices"></a>
<a href="docs/voice-conversion.md"><img src="https://img.shields.io/badge/Voice_Conversion-6e2b3a?style=for-the-badge" alt="Voice conversion"></a>
<a href="docs/c-api.md"><img src="https://img.shields.io/badge/C_API-2b3137?style=for-the-badge" alt="C API"></a>
<a href="docs/ctypes.md"><img src="https://img.shields.io/badge/Python-2b3137?style=for-the-badge" alt="Python"></a>
<a href="docs/performance.md"><img src="https://img.shields.io/badge/Performance-2b3137?style=for-the-badge" alt="Performance"></a>
<a href="docs/architecture.md"><img src="https://img.shields.io/badge/Architecture-2b3137?style=for-the-badge" alt="Architecture"></a>

</div>

## What it does

| Mode | You give it | You get |
| --- | --- | --- |
| **Voice design** | A text description of a voice | A voice invented to match the description |
| **Voice cloning** | A reference clip and its transcript | New speech in that voice |
| **Voice direction** | A reference clip plus an instruction | That voice, steered in tone or pace |
| **Voice conversion** | A recording to respeak, and a target voice | The same performance in a different voice |

## Download

Prebuilt Vulkan builds for Windows and Linux (x64) are on the
[releases page](https://github.com/HoppouAI/Breeze-TTS-2.cpp/releases). They run on NVIDIA, AMD and
Intel GPUs with nothing else to install beyond a current GPU driver, and fall back to the CPU when
there is no GPU. Unpack, grab a model from the [Weights](#weights) section, and run:

```
breeze-server breeze-tts-2-q8_0.gguf --webui
```

Then open http://localhost:8080/. The CPU side needs AVX2, which any x64 CPU from roughly 2013 onwards
has. On Linux the Vulkan loader has to be installed, which it is on any desktop with GPU drivers set up
(the package is `libvulkan1` on Debian and Ubuntu).

## Build

```
git clone --recursive https://github.com/HoppouAI/Breeze-TTS-2.cpp
cd Breeze-TTS-2.cpp
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
```

Add `-DBREEZE_VULKAN=OFF` for a CPU only build. Outputs are `breeze-cli`, `breeze-convert`,
`breeze-server`, `breeze-quantize` and the shared library. See [docs/build.md](docs/build.md).

### Nix

With [Nix](https://nixos.org/) (flake support on), `nix develop` gets you the build environment
above: CMake, Ninja, the Vulkan SDK and the Python conversion deps, plus convenience commands.
`nix develop .#cpu` is a CPU-only shell.

```
breeze-build         # configure + build (Vulkan); pass --cpu to skip Vulkan
breeze-cli           # run build/breeze-cli
breeze-server        # run build/breeze-server
```

The flake also ships a NixOS module that runs `breeze-server` as a systemd service. Model picks
from the Hub catalog are downloaded into the state dir and sha256-verified on every start, saved
voices persist across reboots, and the web UI is one option away:

```nix
{
  inputs.breeze-tts.url = "github:HoppouAI/Breeze-TTS-2.cpp/feat/nix";
  # ...
  modules = [
    breeze-tts.nixosModules.default
    {
      hardware.graphics.enable = true;  # Vulkan driver bits for the GPU backend
      services.breeze-tts = {
        enable = true;
        webui = true;
        model = "q8_0";   # or: customModel = "/path/to/your.gguf";
      };
    }
  ];
}
```

All options, the state-dir layout and the operational details: [nix/README.md](nix/README.md).

## Weights

<div align="center">

<a href="https://huggingface.co/HoppouAI/Breeze-TTS-2.cpp"><img src="https://huggingface.co/datasets/huggingface/badges/resolve/main/model-on-hf-lg.svg" alt="Model on Hugging Face"></a>

</div>

Prebuilt GGUFs are on the Hub at
[HoppouAI/Breeze-TTS-2.cpp](https://huggingface.co/HoppouAI/Breeze-TTS-2.cpp), or convert them
yourself. The download must include the `audio_tokenizer/` directory, which holds the vocoder.

```
pip install -r scripts/requirements.txt
python scripts/convert_hf_to_gguf.py /path/to/Breeze-TTS-2 -o breeze-tts-2-f16.gguf --dtype f16
build/breeze-quantize breeze-tts-2-f16.gguf breeze-tts-2-q4_k.gguf q4_k
```

| Variant | Size | Approximate VRAM | Notes |
| --- | --- | --- | --- |
| F16 | 5.9 GB | ~7 GB | Reference quality |
| Q8_0 | 3.3 GB | ~4 GB | **Recommended** |
| Q6_K | 2.9 GB | ~3.5 GB | |
| Q4_K | 2.4 GB | ~3 GB | Smallest safe choice |
| Q8_0-dd4, Q8_0-dd2, Q4_K-dd2 | 2.3 to 3.4 GB | | Experimental, see below |

The `-dd` variants quantize the depth decoder as well, which the others leave at higher precision.
They can be meaningfully faster on hardware where the depth decoder is the bottleneck, since it runs
15 sequential steps for every single frame of audio. The catch is that depth codes feed back into the
backbone each frame, so error compounds with length: output holds up early and then drifts muffled and
thin past roughly 45 seconds of continuous generation. Fine for short lines, not for narration.

## CLI

```
# voice design
build/breeze-cli breeze-tts-2-q8_0.gguf \
  --text "(sigh) Welcome aboard. Your journey begins now." \
  --instruction "A warm, thoughtful young woman with a clear, calm delivery." \
  --output design.wav

# voice clone
build/breeze-cli breeze-tts-2-q8_0.gguf \
  --text "It is good to hear your voice again." \
  --ref-audio reference.wav --ref-text "Exact transcript of the reference." \
  --output clone.wav

# voice direction
build/breeze-cli breeze-tts-2-q8_0.gguf \
  --text "(clears throat) We need to talk." \
  --instruction "Speak slowly with a restrained, serious tone." \
  --ref-audio reference.wav --ref-text "Exact transcript of the reference." \
  --output direction.wav
```

Encoding a reference clip is the slowest part of a clone and it is deterministic, so save it once with
`--save-voice name` and use `--voice name` from then on. Saved voices load instantly, work in the CLI,
the server and the web UI, and cut time to first audio from around 900 ms to around 280 ms. See
[docs/voices.md](docs/voices.md).

## Vocal events

Inline tags in round brackets produce non speech sounds. `(laugh)`, `(sigh)`, `(cough)` and
`(clears throat)` are the reliable ones, with `[笑]` and `[叹气]` on the Chinese side, but the tag
vocabulary is **free form**. The model was trained on descriptive tags rather than a fixed token list,
so things like `(whispering)`, `(gasp)` or `(nervous chuckle)` will often work.

The catch is that at the default `--cfg-scale 1.0` the model treats a tag as a suggestion and usually
ignores anything outside the common set. **Vocal events generally need `--cfg-scale 2` to `3` to
actually fire**, because guidance is what pushes the output away from plain neutral reading. Expect
some added harshness at that range, so raise it for lines that need the event and drop back to 1.0 for
ordinary speech.

```
build/breeze-cli breeze-tts-2-q8_0.gguf \
  --text "(nervous chuckle) I am sure it is nothing to worry about." \
  --instruction "An anxious man trying to sound casual." \
  --cfg-scale 2.5 --output event.wav
```

## Voice conversion (experimental)

`breeze-convert` respeaks an existing recording in another voice. Unlike cloning, which reads new text,
this keeps the original performance: the timing, the phrasing, the rhythm and the emphasis all survive,
and only the speaker identity changes. This is not part of the upstream model. It falls out of the way
the codec splits semantic content from acoustic detail, so it is unique to this implementation and it is
genuinely experimental.

```
build/breeze-convert breeze-tts-2-q8_0.gguf \
  --source recording.wav --text "Transcript of the recording." \
  --ref-audio target_voice.wav --ref-text "Exact transcript of the target clip." \
  --output converted.wav
```

Worth knowing before you rely on it:

- It defaults to near greedy sampling (`--temp 0.3 --top-k 1`) on purpose. Opening sampling up lets
  source timbre leak back into the result, which measurably weakens the target identity.
- **Pitch is regenerated, not copied.** The take is re-sung in the target voice's own register rather
  than at the source's, so a converted vocal can land a fifth away from the original. Whether the tune
  survives varies by clip, so judge it by ear. `--keep-acoustic 1` or `2` copies the lowest acoustic
  codebooks straight from the source and pulls more of the original contour through, at some cost to
  how cleanly the target voice comes out. Higher values fall apart, and on ordinary speech even 1
  causes warbling, so leave it at 0 unless the source is sung.
- Runs at roughly realtime, so a three minute recording takes about three minutes.
- `--text` is optional but matters most here. Giving the source transcript lines the backbone up with
  the forced codes. The same sung clip came back as "Does it pinch I? Send my tears" textless, and as
  "drink it up, I have no fear" once the lyrics were supplied.

See [docs/voice-conversion.md](docs/voice-conversion.md).

## Server

```
build/breeze-server breeze-tts-2-q8_0.gguf --host 127.0.0.1 --port 8080 --webui
```

Open http://localhost:8080/ for the web UI. The HTTP API streams mono 24 kHz signed 16 bit little
endian PCM, matching the reference server.

```
curl -X POST http://127.0.0.1:8080/v1/audio/speech \
  --form-string "text=(clears throat) We need to talk." \
  --form-string "instruction=Speak slowly with a restrained, serious tone." \
  --form-string "voice_id=narrator" \
  --output out.pcm
```

Use `--form-string` for text fields, not `-F`. A value starting with `(` makes `curl` build a
multipart group instead of sending the text, which bites the moment you use a vocal event tag.

The same endpoint takes OpenAI style JSON too, so SillyTavern and the OpenAI SDKs can use it as a
drop in TTS provider, with MP3, WAV or PCM streamed back and server sent events if you ask for them.
See [docs/server.md](docs/server.md#openai-compatible-requests).

A WebSocket server also comes up on the HTTP port plus one. It takes text incrementally, streams audio
back as it is produced, and supports changing the delivery instruction or cancelling mid sentence,
which is what you want when driving it from a chat model. See [docs/websocket.md](docs/websocket.md).

`--talk` adds a voice call demo at `/talk`: pick a character and talk to it out loud. It uses
[tyger-server](https://github.com/HoppouAI/tyger.cpp) for turn taking and interruptions and any
OpenAI compatible chat server for the replies. You can share your screen in a call so the
character can see it, with a chat model that takes images. See
[docs/server.md](docs/server.md#voice-call-demo).

> **Neither port has authentication or rate limiting.** Keep them bound to `127.0.0.1` unless something
> in front of them is handling that.

## MCP server

[breeze-tts-2-mcp](https://github.com/fortesoft-co/breeze-tts-2-mcp) is an MCP server that gives
MCP-speaking agents the voice toolkit: speaking aloud with voice direction and vocal events
(`speak`, `speechJobs`), multi-voice dialogue and narration as one artifact (`speakScript`),
voice design from a description (`designVoice`), and saved voice [library](docs/voices.md)
management (`saveVoice`, `listVoices`, `deleteVoice`). It drives a running `breeze-server` over
HTTP and coordinates local audio playback across clients.

Setup: clone, `npm install && npm run build`, and point it at the server with `BREEZE_TTS_URL`.
A `breeze-speak` binary and an Agent Skills bundle cover callers without an MCP host. Registering
it with Zed, Claude Code or any stdio MCP client, the full tool list and all environment options
are in the [upstream README](https://github.com/fortesoft-co/breeze-tts-2-mcp).

## Bindings

The shared library exposes a plain C ABI, so any language with an FFI can drive it.

```c
breeze_context * ctx = breeze_init("breeze-tts-2-q8_0.gguf", 1);
breeze_request req = {0};
req.text = "Hello there.";
req.cfg_scale = 1.0f;
req.seed = 42;
breeze_generate_wav(ctx, &req, "out.wav");
breeze_free(ctx);
```

Every field treats `0` as "use the model default", so zero initialising the struct is safe and stays
safe as fields are added. See [docs/c-api.md](docs/c-api.md) and [docs/ctypes.md](docs/ctypes.md).

On mingw the library links the compiler runtime statically, so `vulkan-1.dll` from the GPU driver is
the only external dependency.

## Notes

- `--cfg-scale` defaults to 1.0, matching the reference. Values above 1 run the whole pipeline twice
  and push harder toward the instruction. Past about 3 it turns harsh.
- The vocoder comes from the bundled `audio_tokenizer/`, not the Mimi codec sitting in the main
  checkpoint. The reference never uses that one at inference time.
- Streaming chunks start at 80 ms and grow to 2 seconds. The vocoder keeps its state between chunks and
  only decodes new frames, and the result matches a single pass decode apart from rounding, about 40 dB
  down on real speech.

## License

Source code is [Apache 2.0](LICENSE). The MP3 encoder in `third_party/shine` is a separate submodule under the
LGPL 2.0. The Breeze TTS 2 model weights are governed by the BreezeBlue
Research and Non-Commercial License. You are responsible for complying with the weight license and for
obtaining consent for any reference audio or voices you use.
